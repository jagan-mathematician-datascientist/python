#for scanning the barcode using the webcam
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_PINLA

while True:
    _, frame = cap.read()LA

    decodedObjects = pyzbar.decode(frame)
    for obj in decodedObjects:
        print("Data", obj.data)
        cv2.putText(frame, str(obj.data), (50, 50), font, 2,
                    (255, 0, 0), 3)

    cv2.imshow("Frame", frame)

    key = cv2.waitKey(1)
    if key == 27:
        break
#for creating the bar QRCode    
import qrcode
import pandas as pd

qr=qrcode.QRCode(
    version=1,
    box_size  =15,
    border=5
)

data =pd.DataFrame({"name":['jagan','patta'],
                    "age": [22,20]})

qr.add_data(data)
qr.make(fit=True)
img = qr.make_image(fill="black", back_color = 'white')
img.save('qrcode.png')
