from flask import jsonify,Flask,render_template,Response, flash,redirect, url_for, session,request, logging
from flask_mysqldb import MySQL
from wtforms import Form,StringField,TextAreaField,PasswordField,validators,IntegerField
from camera import Camera
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar
import re
import qrcode

app = Flask(__name__)
app.debug = True

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'jagan'
app.config["MYSQL_PASSWORD"] = 'jaganaston'
app.config['MYSQL_DB'] = "hack"
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)


@app.route('/')
def home():
    return render_template('home.html')


class RegisterForm(Form):
    name = StringField('Name', [validators.length(min=1, max=50)])
    number = StringField("Phone Number", [validators.length(min=10, max=13)])


@app.route('/login', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        na = form.name.data
        Nu = form.number.data
        # Create crusor
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO user(name,number) VALUES(%s,%s)",(na,Nu))
        nan =re.sub("''","",na)
        #cur.execute("CREATE table %s(product varchar(20),quantity numeric(20),rate numeric(20), price numeric(20))",[nan])
        # commit to
        mysql.connection.commit()
        #close connection
        cur.close()
        return redirect('/search')
    return render_template('login.html', form=form)


class SearchForm(Form):
    name = StringField('Search', [validators.length(min=1, max=50)])
    quantity =IntegerField('Quantity',[validators.length(min=1, max=50)])

@app.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm(request.form)
    if request.method == 'POST':
        sre = form.name.data
        text =form.quantity.data
        print(text,sre)
        cur = mysql.connection.cursor()
        srea = re.sub('[A-Z]',"[a-z]",sre)
        result = cur.execute("SELECT * FROM items WHERE type=%s or product = %s", (srea,srea))
        articles = cur.fetchall()
        if result > 0:
            return render_template('search.html', articles=articles, form=form)
        else:
            msg = 'NO DATA FOUND'
            return render_template('search.html', msg=type,form=form)
    return render_template('search.html', form=form)


@app.route("/barcode", methods=['POST','GET'])
def barcode():
    form = SearchForm(request.form)
    lang = request.args.get('proglang', type=str)
    product = request.args.get('product',type=str)
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO purchase(product,quantity) VALUES(%s,%s)",(product,lang))
    mysql.connection.commit()
    cur.execute("UPDATE purchase,items SET purchase.rate = items.price,purchase.price = items.price*purchase.quantity  WHERE items.product = purchase.product")
    mysql.connection.commit()
    return render_template("search.html",form=form)

@app.route("/code")
def code():
    import qrcode
    import pandas as pd
    qr=qrcode.QRCode(
        version=1,
        box_size  =15,
        border=5
    )
    cur=mysql.connection.cursor()
    data =cur.execute("SELECT * from purchase")
    datas = cur.fetchall()
    qr.add_data(datas)
    qr.make(fit=True)
    img = qr.make_image(fill="black", back_color = 'white')
    img.save('qr.png')
    return render_template("code.html")

if __name__ == "__main__":
    app.run()


cur.execute("UPDATE purchase,items SET purchase.rate = items.price,purchase.price = items.price*purchase.quantity  WHERE items.product = purchase.product")
